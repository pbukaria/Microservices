package com.codeintground.moviecatalogservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieCatalogServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
